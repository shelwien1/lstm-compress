./coder c ./sigmoid.inc 1
./coder d 1 2

md5sum -c hashes.txt
